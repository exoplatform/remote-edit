#!/bin/bash

python -O /usr/lib/ithiteditdocumentopener3-dav4/document_opener.pyo "$@"

